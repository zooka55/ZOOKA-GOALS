"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

export default function BrandForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [errorMessage, setErrorMessage] = useState("")

  const [formData, setFormData] = useState({
    email: "",
    whatsappNumber: "",
    facebookLink: "",
    instagramLink: "",
    tiktokLink: "",
    websiteLink: "",
    cashDeposit: false,
    eWallet: false,
    vodafoneCash: false,
    orangeMoney: false,
    etisalatCash: false,
    wePay: false,
    walletNumber: "",
    paymob: false,
    paymentGateway: false,
    paypal: false,
    paymentAccountEmail: "",
    notes: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? (e.target as HTMLInputElement).checked : value,
    }))
  }

  const handleCheckboxChange = (field: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: !prev[field as keyof typeof formData],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setErrorMessage("")
    setSuccessMessage("")

    try {
      const response = await fetch("/api/brands", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "حدث خطأ ما")
      }

      setSuccessMessage("تم حفظ البيانات بنجاح وإرسال الإشعار إلى البريد الإلكتروني!")
      setFormData({
        email: "",
        whatsappNumber: "",
        facebookLink: "",
        instagramLink: "",
        tiktokLink: "",
        websiteLink: "",
        cashDeposit: false,
        eWallet: false,
        vodafoneCash: false,
        orangeMoney: false,
        etisalatCash: false,
        wePay: false,
        walletNumber: "",
        paymob: false,
        paymentGateway: false,
        paypal: false,
        paymentAccountEmail: "",
        notes: "",
      })

      setTimeout(() => setSuccessMessage(""), 3000)
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "خطأ في حفظ البيانات")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4 rtl">
      {successMessage && (
        <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">{successMessage}</div>
      )}
      {errorMessage && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">{errorMessage}</div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-right">1️⃣ بيانات التواصل</CardTitle>
            <CardDescription className="text-right">أضف بيانات التواصل الخاصة بك</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-right block mb-2">
                البريد الإلكتروني (Email) *
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleInputChange}
                placeholder="example@email.com"
                className="text-right"
              />
            </div>
            <div>
              <Label htmlFor="whatsappNumber" className="text-right block mb-2">
                رقم واتساب أعمال
              </Label>
              <Input
                id="whatsappNumber"
                name="whatsappNumber"
                type="tel"
                value={formData.whatsappNumber}
                onChange={handleInputChange}
                placeholder="+20 1234567890"
                className="text-right"
              />
            </div>
          </CardContent>
        </Card>

        {/* Social Media */}
        <Card>
          <CardHeader>
            <CardTitle className="text-right">2️⃣ حسابات السوشيال ميديا</CardTitle>
            <CardDescription className="text-right">لينك حساباتك على مواقع التواصل (اختياري)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="facebookLink" className="text-right block mb-2">
                فيسبوك
              </Label>
              <Input
                id="facebookLink"
                name="facebookLink"
                type="url"
                value={formData.facebookLink}
                onChange={handleInputChange}
                placeholder="https://facebook.com/..."
                className="text-right"
              />
            </div>
            <div>
              <Label htmlFor="instagramLink" className="text-right block mb-2">
                إنستجرام
              </Label>
              <Input
                id="instagramLink"
                name="instagramLink"
                type="url"
                value={formData.instagramLink}
                onChange={handleInputChange}
                placeholder="https://instagram.com/..."
                className="text-right"
              />
            </div>
            <div>
              <Label htmlFor="tiktokLink" className="text-right block mb-2">
                تيك توك
              </Label>
              <Input
                id="tiktokLink"
                name="tiktokLink"
                type="url"
                value={formData.tiktokLink}
                onChange={handleInputChange}
                placeholder="https://tiktok.com/..."
                className="text-right"
              />
            </div>
            <div>
              <Label htmlFor="websiteLink" className="text-right block mb-2">
                موقع إلكتروني (إن وجد)
              </Label>
              <Input
                id="websiteLink"
                name="websiteLink"
                type="url"
                value={formData.websiteLink}
                onChange={handleInputChange}
                placeholder="https://example.com"
                className="text-right"
              />
            </div>
          </CardContent>
        </Card>

        {/* Cash and E-Wallets */}
        <Card>
          <CardHeader>
            <CardTitle className="text-right">3️⃣ خدمات الدفع المتاحة</CardTitle>
            <CardDescription className="text-right">اختر الخيارات المتاحة</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label className="text-right block font-semibold">الإيداع النقدي والمحافظ الإلكترونية</Label>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="cashDeposit"
                    checked={formData.cashDeposit}
                    onCheckedChange={() => handleCheckboxChange("cashDeposit")}
                  />
                  <Label htmlFor="cashDeposit" className="cursor-pointer">
                    إيداع نقدي
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="eWallet"
                    checked={formData.eWallet}
                    onCheckedChange={() => handleCheckboxChange("eWallet")}
                  />
                  <Label htmlFor="eWallet" className="cursor-pointer">
                    محافظ إلكترونية
                  </Label>
                </div>
              </div>
            </div>

            {formData.eWallet && (
              <div className="space-y-3 bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
                <Label className="text-right block font-semibold text-sm">المحافظ المدعومة</Label>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="vodafoneCash"
                      checked={formData.vodafoneCash}
                      onCheckedChange={() => handleCheckboxChange("vodafoneCash")}
                    />
                    <Label htmlFor="vodafoneCash" className="cursor-pointer">
                      Vodafone Cash (010)
                    </Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="orangeMoney"
                      checked={formData.orangeMoney}
                      onCheckedChange={() => handleCheckboxChange("orangeMoney")}
                    />
                    <Label htmlFor="orangeMoney" className="cursor-pointer">
                      Orange Money (012)
                    </Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="etisalatCash"
                      checked={formData.etisalatCash}
                      onCheckedChange={() => handleCheckboxChange("etisalatCash")}
                    />
                    <Label htmlFor="etisalatCash" className="cursor-pointer">
                      Etisalat Cash (011)
                    </Label>
                  </div>
                  <div className="flex items-center gap-3">
                    <Checkbox
                      id="wePay"
                      checked={formData.wePay}
                      onCheckedChange={() => handleCheckboxChange("wePay")}
                    />
                    <Label htmlFor="wePay" className="cursor-pointer">
                      WE Pay (015)
                    </Label>
                  </div>
                </div>
              </div>
            )}

            {(formData.vodafoneCash || formData.orangeMoney || formData.etisalatCash || formData.wePay) && (
              <div>
                <Label htmlFor="walletNumber" className="text-right block mb-2">
                  رقم المحفظة المستخدم
                </Label>
                <Input
                  id="walletNumber"
                  name="walletNumber"
                  type="tel"
                  value={formData.walletNumber}
                  onChange={handleInputChange}
                  placeholder="+20 1234567890"
                  className="text-right"
                />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Gateways */}
        <Card>
          <CardHeader>
            <CardTitle className="text-right">4️⃣ بوابات الدفع الإلكتروني</CardTitle>
            <CardDescription className="text-right">هل لديك حساب على أي من هذه البوابات؟</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Checkbox
                  id="paymob"
                  checked={formData.paymob}
                  onCheckedChange={() => handleCheckboxChange("paymob")}
                />
                <Label htmlFor="paymob" className="cursor-pointer">
                  Paymob
                </Label>
              </div>
              <div className="flex items-center gap-3">
                <Checkbox
                  id="paymentGateway"
                  checked={formData.paymentGateway}
                  onCheckedChange={() => handleCheckboxChange("paymentGateway")}
                />
                <Label htmlFor="paymentGateway" className="cursor-pointer">
                  Payment
                </Label>
              </div>
              <div className="flex items-center gap-3">
                <Checkbox
                  id="paypal"
                  checked={formData.paypal}
                  onCheckedChange={() => handleCheckboxChange("paypal")}
                />
                <Label htmlFor="paypal" className="cursor-pointer">
                  PayPal
                </Label>
              </div>
            </div>

            <div>
              <Label htmlFor="paymentAccountEmail" className="text-right block mb-2">
                الإيميل أو رقم الحساب (اختياري)
              </Label>
              <Input
                id="paymentAccountEmail"
                name="paymentAccountEmail"
                type="text"
                value={formData.paymentAccountEmail}
                onChange={handleInputChange}
                placeholder="email@example.com أو رقم الحساب"
                className="text-right"
              />
            </div>
          </CardContent>
        </Card>

        {/* Additional Notes */}
        <Card>
          <CardHeader>
            <CardTitle className="text-right">5️⃣ ملاحظات إضافية</CardTitle>
            <CardDescription className="text-right">أي تفاصيل إضافية تود إضافتها (اختياري)</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              name="notes"
              value={formData.notes}
              onChange={handleInputChange}
              placeholder="أضف أي ملاحظات إضافية هنا..."
              className="min-h-24 text-right"
            />
          </CardContent>
        </Card>

        {/* Submit Button */}
        <Button type="submit" disabled={isLoading} className="w-full py-6 text-lg font-semibold">
          {isLoading ? "جاري الحفظ..." : "حفظ البيانات"}
        </Button>
      </form>
    </div>
  )
}
