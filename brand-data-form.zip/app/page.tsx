"use client"
import BrandForm from "@/components/brand-form"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">بيانات البراند</h1>
          <p className="text-muted-foreground text-lg">أضف بيانات عملك أو نشاطك التجاري</p>
        </div>
        <BrandForm />
      </div>
    </div>
  )
}
