import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { Resend } from "resend"

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(request: NextRequest) {
  try {
    const cookieStore = await cookies()

    const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
          } catch {
            // Handle errors in setting cookies
          }
        },
      },
    })

    const body = await request.json()

    // Validate required email field
    if (!body.email) {
      return NextResponse.json({ error: "البريد الإلكتروني مطلوب" }, { status: 400 })
    }

    // Insert data into brands table
    const { data, error } = await supabase
      .from("brands")
      .insert([
        {
          email: body.email,
          whatsapp_number: body.whatsappNumber || null,
          facebook_link: body.facebookLink || null,
          instagram_link: body.instagramLink || null,
          tiktok_link: body.tiktokLink || null,
          website_link: body.websiteLink || null,
          cash_deposit: body.cashDeposit,
          e_wallet: body.eWallet,
          vodafone_cash: body.vodafoneCash,
          orange_money: body.orangeMoney,
          etisalat_cash: body.etisalatCash,
          we_pay: body.wePay,
          wallet_number: body.walletNumber || null,
          paymob: body.paymob,
          payment_gateway: body.paymentGateway,
          paypal: body.paypal,
          payment_account_email: body.paymentAccountEmail || null,
          notes: body.notes || null,
        },
      ])
      .select()

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json({ error: "خطأ في حفظ البيانات" }, { status: 500 })
    }

    const emailContent = `
      <div dir="rtl" style="font-family: Arial, sans-serif; padding: 20px; background-color: #f5f5f5; border-radius: 8px;">
        <h2 style="color: #333; text-align: right; border-bottom: 2px solid #007bff; padding-bottom: 10px;">
          نموذج بيانات براند جديد
        </h2>
        
        <div style="background-color: white; padding: 20px; border-radius: 6px; margin-top: 15px;">
          <h3 style="color: #007bff; text-align: right; margin-top: 0;">1. بيانات التواصل</h3>
          <p><strong>البريد الإلكتروني:</strong> ${body.email}</p>
          <p><strong>رقم واتساب:</strong> ${body.whatsappNumber || "لم يتم التحديد"}</p>
          
          <h3 style="color: #007bff; text-align: right;">2. حسابات السوشيال ميديا</h3>
          <p><strong>فيسبوك:</strong> ${body.facebookLink || "لم يتم التحديد"}</p>
          <p><strong>إنستجرام:</strong> ${body.instagramLink || "لم يتم التحديد"}</p>
          <p><strong>تيك توك:</strong> ${body.tiktokLink || "لم يتم التحديد"}</p>
          <p><strong>موقع إلكتروني:</strong> ${body.websiteLink || "لم يتم التحديد"}</p>
          
          <h3 style="color: #007bff; text-align: right;">3. خدمات الدفع المتاحة</h3>
          <p><strong>إيداع نقدي:</strong> ${body.cashDeposit ? "نعم" : "لا"}</p>
          <p><strong>محافظ إلكترونية:</strong> ${body.eWallet ? "نعم" : "لا"}</p>
          ${
            body.eWallet
              ? `
            <p style="margin-right: 20px;">
              <strong>المحافظ المدعومة:</strong>
              ${body.vodafoneCash ? "Vodafone Cash (010)" : ""}
              ${body.orangeMoney ? ", Orange Money (012)" : ""}
              ${body.etisalatCash ? ", Etisalat Cash (011)" : ""}
              ${body.wePay ? ", WE Pay (015)" : ""}
            </p>
            <p style="margin-right: 20px;"><strong>رقم المحفظة:</strong> ${body.walletNumber || "لم يتم التحديد"}</p>
          `
              : ""
          }
          
          <h3 style="color: #007bff; text-align: right;">4. بوابات الدفع الإلكتروني</h3>
          <p><strong>Paymob:</strong> ${body.paymob ? "نعم" : "لا"}</p>
          <p><strong>Payment:</strong> ${body.paymentGateway ? "نعم" : "لا"}</p>
          <p><strong>PayPal:</strong> ${body.paypal ? "نعم" : "لا"}</p>
          ${
            body.paymob || body.paymentGateway || body.paypal
              ? `
            <p><strong>بيانات الحساب:</strong> ${body.paymentAccountEmail || "لم يتم التحديد"}</p>
          `
              : ""
          }
          
          <h3 style="color: #007bff; text-align: right;">5. ملاحظات إضافية</h3>
          <p>${body.notes || "لا توجد ملاحظات"}</p>
        </div>
        
        <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
          <p>تم إرسال هذه الرسالة تلقائياً من نموذج بيانات البراند</p>
        </div>
      </div>
    `

    try {
      await resend.emails.send({
        from: "noreply@resend.dev",
        to: "zookagaming475@gmail.com",
        subject: `بيانات براند جديد: ${body.email}`,
        html: emailContent,
      })
    } catch (emailError) {
      console.error("Email sending error:", emailError)
      // Don't fail the request if email fails, still return success
    }

    return NextResponse.json({ success: true, data }, { status: 201 })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "خطأ في معالجة الطلب" }, { status: 500 })
  }
}
